function events.render()
    models.model.Body.cape:setRot(cape_rotation)
end