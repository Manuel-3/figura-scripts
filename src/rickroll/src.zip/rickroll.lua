function events.tick()
    models.rickroll.PORTRAIT:setUV(world.getTime()/54,0)
end