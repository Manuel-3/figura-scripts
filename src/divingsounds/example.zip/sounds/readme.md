Put sounds here, with the following names:

- leviathan.ogg
- depth_100.ogg
- depth_200.ogg
- oxygen.ogg
- 30seconds.ogg

Make sure the encoding is ogg vorbis with stereo.